from odoo import fields, models, api
import datetime
from odoo.exceptions import UserError, ValidationError
from dateutil.relativedelta import relativedelta

class Product(models.Model):
    _inherit = 'product.product'

    property_size = fields.Float(string="Property Size Area", required=True)
    property_maintenance_charge = fields.Float(compute="clac_maintenance_charge")
    property_no = fields.Char(string="Property NO")
    wifi = fields.Char(string="Wifi")
    wifi_username = fields.Char(string="Wifi username")
    wifi_password = fields.Char(string="Wifi password")
    meter = fields.Float(string="Electricity Meter Number")
    meter_kw_in_arriving = fields.Float(string="Meter KW Arriving")
    meter_kw_in_departure = fields.Float(string="Meter KW Departure")
    club_fees = fields.Float(string="Gym")
    diesel_fees = fields.Float(string="Diesel")
    # facility_ids = fields.One2many('facility.services.line', 'property_id')

    @api.depends('property_maintenance_charge')
    def clac_maintenance_charge(self):
        ps = self.env['property.size'].search([])

        self.property_maintenance_charge = self.property_size * ps.price

    def create_maintenance_invoice(self):
        invoice_vals = {
            'partner_id': self.property_landlord_id.id,
            'state': 'draft',
            'invoice_date': datetime.datetime.today().date(),
            'is_property_invoice': True,
            'property_id': self.id,
            'invoice_payment_term_id': 1,
            'move_type': 'out_invoice',
            'invoice_line_ids': [(0, 0, {
                'product_id': self.id,
                'name': self.name +''+"Service Cost",
                'quantity': 1,
                'price_unit': self.property_maintenance_charge,
            })]
        }
        # self.state = 'invoiced'
        invoice = self.env['account.move'].sudo().create(invoice_vals)
        return invoice

class ContractCon(models.Model):
    _inherit ='sr.tenancy.agreement'

    facility_ids = fields.One2many('facility.lines', 'rel_id')
    deposit = fields.Float(string="Deposit")
    terms_conditionas = fields.Text(string="Terms of payment")
    gym = fields.Selection([('inc','Include'),('not_inc','Not include')])
    diesel = fields.Selection([('inc','Include'),('not_inc','Not include')])
    gym_fee = fields.Float(related="property_id.club_fees")
    diesel_fee = fields.Float(related="property_id.diesel_fees")

    @api.depends('property_id', 'agreement_start_date', 'agreement_duration', 'agreement_duration_type')
    def _compute_amount_all(self):
        for order in self:
            num_months = 0
            if order.agreement_start_date and order.agreement_duration and order.agreement_duration_type:
                if order.agreement_duration_type == 'month':
                    order.agreement_expiry_date = order.agreement_start_date + relativedelta(months=order.agreement_duration)
                else:
                    order.agreement_expiry_date = order.agreement_start_date + relativedelta(years=order.agreement_duration)
                num_months = (order.agreement_expiry_date.year - order.agreement_start_date.year) * 12 + (order.agreement_expiry_date.month - order.agreement_start_date.month)
                difference = relativedelta(order.agreement_expiry_date, order.agreement_start_date)
            else:
                order.agreement_expiry_date = False
                
            if order.property_id.property_type == 'rent':
                commission = 0
                if order.commission_type == 'percentage':
                    commission = (num_months * order.property_id.property_rent_price) * (order.agent_commission / 100)
                else:
                    commission = order.agent_commission
                # if order.maintenance_interval_type == "month":
                #     maintenance_charge = order.property_id.property_maintenance_charge * num_months
                # else:
                #     if difference.years > 1:
                #         maintenance_charge = order.property_id.property_maintenance_charge * difference.years
                #     else:
                #         maintenance_charge = order.property_id.property_maintenance_charge * 1
                    
                order.update({
                    'total_price': num_months * order.property_id.property_rent_price,
                    # 'total_maintenance':maintenance_charge,
                    'commission_price':commission,
                    'final_price' : (num_months * order.property_id.property_rent_price) + commission 
                })
            elif order.property_id.property_type == 'sale':
                if order.commission_type == 'percentage':
                    commission = (order.property_sale_price) * (order.agent_commission / 100)
                else:
                    commission = order.agent_commission
                order.update({
                    'total_price': order.property_sale_price,
                    # 'total_maintenance':order.maintenance_charge,
                    'commission_price':commission,
                    'final_price' : commission + order.property_sale_price
                })
            else:
                order.update({
                    'total_price': 0,
                    # 'total_maintenance':0,
                    'commission_price':0,
                    'final_price' : 0
                })
    
class FacilityServicesLine(models.Model):
	_name = 'facility.lines'

	facility_id = fields.Many2one('property.facility', required=True, store=True)
	count = fields.Integer(string="Count", required=True)
	is_exist = fields.Boolean(string="Existing ?", required=True)
	rel_id = fields.Many2one('sr.tenancy.agreement')


	@api.onchange('is_exist')
	def set_count_to_zero_for_facility_when_not_exist(self):
		for rec in self:
			if not rec.is_exist:
				rec.count = 0


