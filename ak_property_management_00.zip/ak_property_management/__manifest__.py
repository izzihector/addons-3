{
    'name': 'AK Property',
    'version': '14.0',
    'summary': 'Summery',
    'description': 'Description',
    'category': 'Category',
    'author': 'Author',
    'depends': ['sr_property_rental_management','maintenance'],
    'data': [
        'security/ir.model.access.csv',
        'views/all_xml_in_one.xml',
        'views/maintanance.xml',
        'views/generators.xml',
        'reports/renter_card_report_teamplate_pdf.xml',
        'reports/facility_service_report.xml',
    ],

    'installable': True,
    'auto_install': False
}
